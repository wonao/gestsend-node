const { createUserTable } = require("../src/models/userModel");

createUserTable();

