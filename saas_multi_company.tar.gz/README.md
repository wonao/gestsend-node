# Logiciel SaaS de Gestion d'Entreprise Multiples

Ce projet est un prototype fonctionnel d'un logiciel SaaS de gestion d'entreprise multiples, avec une interface utilisateur moderne et intuitive, développé en Full JavaScript (Node.js pour le backend, React.js pour le frontend) et utilisant SQLite pour la base de données.

## Table des Matières

- [Installation Locale](#installation-locale)
- [Déploiement sur o2switch](#déploiement-sur-o2switch)
- [Structure des Dossiers](#structure-des-dossiers)
- [API RESTful](#api-restful)
- [Structure des Tables SQLite](#structure-des-tables-sqlite)
- [Fonctionnalités Clés (MVP)](#fonctionnalités-clés-mvp)

## Installation Locale

Suivez ces étapes pour installer et exécuter le projet en local.

### Prérequis

Assurez-vous d'avoir les éléments suivants installés sur votre machine :

- Node.js (version 14 ou supérieure)
- npm (Node Package Manager)

### Backend (Node.js)

1. Naviguez vers le répertoire `backend` :
   ```bash
   cd backend
   ```
2. Installez les dépendances :
   ```bash
   npm install
   ```
3. Créez le fichier `.env` à la racine du répertoire `backend` et ajoutez les variables d'environnement suivantes :
   ```
   PORT=3000
   JWT_SECRET=votre_clé_secrète_jwt
   ```
4. Initialisez la base de données SQLite :
   ```bash
   node scripts/init_db.js
   ```
5. Démarrez le serveur backend :
   ```bash
   npm start
   ```
   Le serveur devrait démarrer sur `http://localhost:3000`.

### Frontend (React.js)

1. Ouvrez un nouveau terminal et naviguez vers le répertoire `frontend` :
   ```bash
   cd frontend
   ```
2. Installez les dépendances :
   ```bash
   npm install
   ```
3. Créez le fichier `.env` à la racine du répertoire `frontend` et ajoutez la variable d'environnement suivante :
   ```
   REACT_APP_API_URL=http://localhost:3000/api
   ```
4. Démarrez l'application frontend :
   ```bash
   npm start
   ```
   L'application devrait s'ouvrir dans votre navigateur par défaut sur `http://localhost:3001` (ou un autre port disponible).

## Déploiement sur o2switch

Ce projet est configuré pour un déploiement facile sur un environnement Node.js chez o2switch. Voici les étapes générales :

1. **Préparation du projet :**
   - Assurez-vous que toutes les dépendances sont installées (`npm install` dans `backend` et `frontend`).
   - Pour le frontend, exécutez `npm run build` dans le répertoire `frontend` pour générer les fichiers statiques de production. Ces fichiers seront dans le dossier `frontend/build`.

2. **Configuration chez o2switch :**
   - Connectez-vous à votre interface cPanel chez o2switch.
   - Utilisez l'outil 


   **"Setup Node.js App"** pour créer une nouvelle application Node.js.
   - Spécifiez le chemin de l'application (par exemple, `gestsend0-1.sufa0372.odns.fr/`).
   - Définissez le répertoire racine de l'application Node.js sur le répertoire `backend` de votre projet (par exemple, `/home/votre_utilisateur/public_html/gestsend0-1.sufa0372.odns.fr/backend`).
   - Assurez-vous que le script de démarrage est `app.js` ou `server.js`.
   - Configurez le port d'écoute pour qu'il utilise la variable d'environnement `PORT` fournie par o2switch.

3. **Transfert des fichiers :**
   - Transférez l'intégralité de votre projet (répertoires `backend` et `frontend`) vers le répertoire spécifié sur votre hébergement o2switch (par exemple, `/home/votre_utilisateur/public_html/gestsend0-1.sufa0372.odns.fr/`).
   - Assurez-vous que le contenu du dossier `frontend/build` (généré après `npm run build`) est accessible via votre serveur web pour servir l'application frontend.

4. **Variables d'environnement :**
   - Configurez les variables d'environnement (`JWT_SECRET`, `DB_PATH`, etc.) directement dans l'interface de configuration de l'application Node.js chez o2switch, ou assurez-vous que votre fichier `.env` est correctement chargé.

5. **Démarrage de l'application :**
   - Une fois les fichiers transférés et la configuration effectuée, démarrez l'application Node.js via l'interface o2switch.

## Structure des Dossiers

Le projet est organisé en deux répertoires principaux : `backend/` et `frontend/`.

### `backend/` (Node.js/Express.js)

```
backend/
    src/ (ou app/)
        config/ (fichiers de configuration, ex: DB, JWT)
        controllers/ (logique métier des routes)
        models/ (définition des modèles de données et interactions DB)
        routes/ (définition des routes API)
        middlewares/ (fonctions middleware, ex: authentification, validation)
        utils/ (fonctions utilitaires)
        services/ (logique métier complexe, si nécessaire)
        app.js (fichier principal de l'application Express)
    data/ (pour le fichier SQLite .db)
    scripts/ (pour le script d'initialisation de la DB)
    package.json
    .env (variables d'environnement)
```

### `frontend/` (React.js)

```
frontend/
    src/
        components/ (composants UI réutilisables, ex: Button, Card)
        pages/ (ou views/) (composants représentant des pages complètes, ex: Dashboard, Login)
        assets/ (images, icônes, styles globaux)
        services/ (fonctions pour les appels API)
        utils/ (fonctions utilitaires spécifiques au frontend)
        contexts/ (si React, pour la gestion d'état global)
        hooks/ (si React, pour les hooks personnalisés)
        App.js (composant racine de l'application)
        index.js (point d'entrée de l'application)
    public/ (fichiers statiques, ex: index.html)
    package.json
    .env (variables d'environnement spécifiques au frontend)
```

## API RESTful

Voici les endpoints principaux de l'API RESTful :

### Authentification

- **`POST /api/auth/register`**
  - **Description :** Enregistre un nouvel utilisateur.
  - **Requête :**
    ```json
    {
      "username": "nom_utilisateur",
      "password": "mot_de_passe"
    }
    ```
  - **Réponse (Succès) :**
    ```json
    {
      "auth": true,
      "token": "votre_jeton_jwt"
    }
    ```
  - **Réponse (Erreur) :**
    ```json
    {
      "auth": false,
      "message": "Message d'erreur"
    }
    ```

- **`POST /api/auth/login`**
  - **Description :** Connecte un utilisateur existant.
  - **Requête :**
    ```json
    {
      "username": "nom_utilisateur",
      "password": "mot_de_passe"
    }
    ```
  - **Réponse (Succès) :**
    ```json
    {
      "auth": true,
      "token": "votre_jeton_jwt"
    }
    ```
  - **Réponse (Erreur) :**
    ```json
    {
      "auth": false,
      "message": "Message d'erreur"
    }
    ```

## Structure des Tables SQLite

Le fichier `backend/scripts/init_db.js` créera la table `users` si elle n'existe pas :

```sql
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  password TEXT
);
```

Des tables supplémentaires pour la gestion des entreprises, la comptabilité, le CRM et les réseaux sociaux seront ajoutées au fur et à mesure du développement.

## Fonctionnalités Clés (MVP)

### Gestion des Utilisateurs et Authentification
- Système d'inscription et de connexion sécurisé (JWT pour l'authentification).
- Gestion des rôles (ex: Administrateur, Gérant d'entreprise, Employé).
- Chaque utilisateur peut être associé à une ou plusieurs entreprises.

### Gestion Multi-Entreprises
- Possibilité pour un utilisateur de créer et de gérer plusieurs entreprises distinctes.
- Chaque entreprise aura ses propres données isolées (comptabilité, CRM, etc.).
- Interface de sélection/changement d'entreprise pour l'utilisateur.

### Module de Comptabilité Simplifiée
- Gestion des revenus et des dépenses (catégorisation, date, montant, description).
- Tableau de bord financier simple (résumé des revenus/dépenses par période).

### Module CRM Basique
- Gestion des contacts (nom, email, téléphone, entreprise associée).
- Suivi des interactions (notes, dates).

### Module de Gestion des Réseaux Sociaux (Placeholder)
- Un tableau de bord simple affichant des liens vers les profils sociaux de l'entreprise.
- (Optionnel si le temps le permet) Un champ pour planifier un post simple (texte seulement) sans intégration API réelle dans cette version initiale.

### Tableau de Bord Général (User-Friendly)
- Page d'accueil présentant un aperçu consolidé des données clés.
- Visualisations : Utilisation de bibliothèques de graphiques (ex: Chart.js, Recharts) pour afficher des camemberts et des graphiques à barres/lignes pour :
    - Répartition des revenus/dépenses par catégorie.
    - Évolution des revenus/dépenses sur une période.
    - Nombre de contacts CRM.
- Design épuré, moderne et responsive.


