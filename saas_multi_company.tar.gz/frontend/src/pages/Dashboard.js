import React from 'react';
import { Container, Typography, Box } from '@mui/material';

function Dashboard() {
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Tableau de Bord Général
        </Typography>
        <Typography variant="body1">
          Bienvenue sur votre tableau de bord. Ici, vous trouverez un aperçu de vos données d'entreprise.
        </Typography>
      </Box>
    </Container>
  );
}

export default Dashboard;

